+++
title = 'Version 2.2'
type = 'changelog'
weight = -2

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
