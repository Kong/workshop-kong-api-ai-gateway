+++
title = 'Version 2.0'
type = 'changelog'
weight = 0

[params]
  disableToc = false
  hidden = true
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
