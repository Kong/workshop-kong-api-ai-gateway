+++
title = 'Version 2.9'
type = 'changelog'
weight = -9

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
