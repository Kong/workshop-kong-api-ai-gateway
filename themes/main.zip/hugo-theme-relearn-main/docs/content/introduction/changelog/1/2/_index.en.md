+++
title = 'Version 1.2'
type = 'changelog'
weight = -2

[params]
  disableToc = false
  hidden = true
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
