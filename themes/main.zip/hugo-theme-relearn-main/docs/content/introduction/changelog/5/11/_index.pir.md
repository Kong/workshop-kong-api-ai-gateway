+++
title = 'Version 5.11'
type = 'changelog'
weight = -11

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
