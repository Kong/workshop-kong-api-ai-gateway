+++
title = 'Version 5.10'
type = 'changelog'
weight = -10

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
