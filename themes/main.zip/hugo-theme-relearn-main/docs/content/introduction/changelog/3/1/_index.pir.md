+++
title = 'Version 3.1'
type = 'changelog'
weight = -1

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
