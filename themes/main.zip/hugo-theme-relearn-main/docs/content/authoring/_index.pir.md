+++
categories = ['reference']
title = "Rambl'n"
type = 'chapter'
weight = 3

[params]
  menuPre = "<i class='fa-fw fab fa-markdown'></i> "
+++
{{< piratify >}}