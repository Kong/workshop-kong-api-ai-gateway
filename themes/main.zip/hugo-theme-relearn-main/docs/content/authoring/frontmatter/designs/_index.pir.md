+++
categories = ['howto']
description = 'How to vary layouts by using page designs'
title = 'Page Designs'
weight = 1
+++
{{< piratify >}}