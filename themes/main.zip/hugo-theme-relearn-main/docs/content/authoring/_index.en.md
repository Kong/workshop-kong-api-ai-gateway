+++
categories = ['reference']
title = 'Authoring'
type = 'chapter'
weight = 3

[params]
  menuPre = "<i class='fa-fw fab fa-markdown'></i> "
+++

Learn how to create and organize your content pages.

{{% children containerstyle="div" style="h2" description=true %}}
