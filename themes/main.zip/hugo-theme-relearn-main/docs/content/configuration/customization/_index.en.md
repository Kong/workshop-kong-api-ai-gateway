+++
categories = ['reference']
description = 'Customize files for advanced usage'
title = 'Customization'
weight = 5

[params]
  alwaysopen = false
+++

{{% children containerstyle="div" style="h2" description=true %}}
