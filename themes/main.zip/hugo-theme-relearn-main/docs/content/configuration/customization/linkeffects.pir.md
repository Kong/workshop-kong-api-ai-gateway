+++
categories = ['explanation', 'howto']
description = 'How to extend link effects'
options = ['linkEffects']
title = 'Link Effects'
weight = 3
+++
{{< piratify >}}