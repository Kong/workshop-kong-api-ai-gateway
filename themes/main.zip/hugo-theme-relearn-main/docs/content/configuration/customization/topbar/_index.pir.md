+++
categories = ['explanation', 'reference']
description = 'How to extend the topbar'
options = ['editURL']
outputs = ['html', 'rss', 'print', 'markdown', 'source']
title = 'Topbarrr'
weight = 5
+++
{{< piratify >}}