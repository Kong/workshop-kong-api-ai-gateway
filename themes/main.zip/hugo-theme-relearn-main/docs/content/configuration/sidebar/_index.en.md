+++
categories = ['reference']
description = 'Configure all things sidebar'
title = 'Sidebar'
weight = 3

[params]
  alwaysopen = false
+++

{{% children containerstyle="div" style="h2" description=true %}}
