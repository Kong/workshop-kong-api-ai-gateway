+++
categories = ['howto']
description = 'What options are available for links and images'
options = ['disableDefaultRelref', 'disableExplicitIndexURLs', 'enableLegacyLanguageLinks']
title = 'Linking'
weight = 5
+++
{{< piratify >}}