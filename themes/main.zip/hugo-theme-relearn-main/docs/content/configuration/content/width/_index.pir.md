+++
categories = ['howto']
description = 'Changing the content area width'
title = 'Width'
weight = 1
+++
{{< piratify >}}