+++
categories = ['howto']
description = 'Configuring heading anchors'
options = ['disableAnchorCopy', 'disableAnchorScrolling']
title = 'Headings'
weight = 4
+++
{{< piratify >}}