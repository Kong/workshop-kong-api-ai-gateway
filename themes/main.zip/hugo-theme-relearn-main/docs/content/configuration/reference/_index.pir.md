+++
categories = ['reference']
description = 'All configuration options for the Relearn theme'
title = 'Options Reference'
weight = 6
+++
{{< piratify >}}