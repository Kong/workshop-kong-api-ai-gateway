+++
categories = ['howto']
description = 'Colors of syntax highlighting and 3rd-party modules'
title = 'Module Theming'
weight = 3
+++
{{< piratify >}}